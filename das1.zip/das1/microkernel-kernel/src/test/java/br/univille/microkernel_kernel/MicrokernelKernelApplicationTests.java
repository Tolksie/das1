package br.univille.microkernel_kernel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrokernelKernelApplicationTests {

	@Test
	void contextLoads() {
	}

}
